rootProject.name = "LivingVillages-Free"
